# Sca-N

Scan, Understand, Research, Ask, Save.

## Repository layout
- `flutter_app/` — Flutter mobile application
- `backend/` — FastAPI backend foundation
- `supabase/` — database migrations
- `docs/` — architecture documentation

## Android CI
GitHub Actions builds a debug APK on pushes to `main` and manual runs. The build creates the Android platform files if they are not yet committed, then runs `flutter pub get`, `flutter analyze`, and builds the APK.

Production Supabase credentials and signing keys are not stored in the repository.
