-- Sca-N initial production-oriented schema
-- Supabase/PostgreSQL

create extension if not exists pgcrypto;

-- ---------- ENUMS ----------
create type public.discovery_kind as enum ('scan', 'search');
create type public.saved_kind as enum ('place', 'product', 'object', 'document', 'other');
create type public.message_role as enum ('user', 'assistant', 'system', 'tool');
create type public.run_status as enum ('queued', 'running', 'completed', 'failed', 'cancelled');

-- ---------- PROFILE ----------
create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text,
  avatar_url text,
  language_code text not null default 'en',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- ---------- INPUTS ----------
create table public.scans (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  image_path text,
  input_hash text,
  created_at timestamptz not null default now()
);

create table public.searches (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  query text not null,
  location_scope text,
  created_at timestamptz not null default now()
);

-- ---------- AI RESULT ----------
create table public.results (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  result_type text not null,
  title text not null,
  subtitle text,
  confidence numeric(5,4),
  payload jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint results_confidence_range check (confidence is null or (confidence >= 0 and confidence <= 1))
);

create table public.result_sections (
  id uuid primary key default gen_random_uuid(),
  result_id uuid not null references public.results(id) on delete cascade,
  section_type text not null,
  position integer not null default 0,
  data jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  unique (result_id, position)
);

create table public.sources (
  id uuid primary key default gen_random_uuid(),
  result_id uuid not null references public.results(id) on delete cascade,
  title text,
  url text,
  publisher text,
  source_type text,
  accessed_at timestamptz,
  metadata jsonb not null default '{}'::jsonb
);

-- ---------- DISCOVERIES / SAVED ----------
create table public.discoveries (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  result_id uuid not null references public.results(id) on delete cascade,
  kind public.discovery_kind not null,
  source_id uuid,
  created_at timestamptz not null default now(),
  unique (user_id, result_id)
);

create table public.saved_items (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  result_id uuid not null references public.results(id) on delete cascade,
  kind public.saved_kind not null default 'other',
  created_at timestamptz not null default now(),
  unique (user_id, result_id)
);

-- ---------- CONVERSATIONS / ASK MORE ----------
create table public.conversations (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  result_id uuid references public.results(id) on delete set null,
  title text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.messages (
  id uuid primary key default gen_random_uuid(),
  conversation_id uuid not null references public.conversations(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  role public.message_role not null,
  content text,
  payload jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

-- ---------- UPLOADS ----------
create table public.uploads (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  storage_path text not null,
  mime_type text,
  byte_size bigint,
  purpose text,
  created_at timestamptz not null default now()
);

-- ---------- AGENT OBSERVABILITY ----------
create table public.agent_runs (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references auth.users(id) on delete cascade,
  request_type text not null,
  status public.run_status not null default 'queued',
  model text,
  latency_ms integer,
  error_code text,
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  completed_at timestamptz
);

create table public.tool_calls (
  id uuid primary key default gen_random_uuid(),
  agent_run_id uuid not null references public.agent_runs(id) on delete cascade,
  tool_name text not null,
  status public.run_status not null default 'queued',
  latency_ms integer,
  error_code text,
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  completed_at timestamptz
);

-- ---------- FEEDBACK ----------
create table public.feedback (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references auth.users(id) on delete set null,
  result_id uuid references public.results(id) on delete set null,
  rating smallint,
  message text,
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  constraint feedback_rating_range check (rating is null or rating between 1 and 5)
);

-- ---------- AGGREGATED PUBLIC TRENDS ----------
-- No user_id here by design. Populate/update only from trusted backend jobs.
create table public.popular_searches (
  id uuid primary key default gen_random_uuid(),
  normalized_query text not null,
  display_query text not null,
  location_scope text,
  period_start date not null,
  period_end date not null,
  search_count bigint not null default 0,
  unique (normalized_query, location_scope, period_start, period_end)
);

-- ---------- INDEXES ----------
create index scans_user_created_idx on public.scans(user_id, created_at desc);
create index searches_user_created_idx on public.searches(user_id, created_at desc);
create index results_user_created_idx on public.results(user_id, created_at desc);
create index discoveries_user_created_idx on public.discoveries(user_id, created_at desc);
create index saved_user_created_idx on public.saved_items(user_id, created_at desc);
create index conversations_user_updated_idx on public.conversations(user_id, updated_at desc);
create index messages_conversation_created_idx on public.messages(conversation_id, created_at);
create index uploads_user_created_idx on public.uploads(user_id, created_at desc);
create index agent_runs_user_created_idx on public.agent_runs(user_id, created_at desc);
create index tool_calls_run_created_idx on public.tool_calls(agent_run_id, created_at);
create index popular_searches_period_idx on public.popular_searches(period_end desc, search_count desc);

-- ---------- RLS ----------
alter table public.profiles enable row level security;
alter table public.scans enable row level security;
alter table public.searches enable row level security;
alter table public.results enable row level security;
alter table public.result_sections enable row level security;
alter table public.sources enable row level security;
alter table public.discoveries enable row level security;
alter table public.saved_items enable row level security;
alter table public.conversations enable row level security;
alter table public.messages enable row level security;
alter table public.uploads enable row level security;
alter table public.agent_runs enable row level security;
alter table public.tool_calls enable row level security;
alter table public.feedback enable row level security;
alter table public.popular_searches enable row level security;

-- User-owned tables: owner can CRUD their own rows.
create policy profiles_owner_all on public.profiles for all to authenticated
  using (id = (select auth.uid()))
  with check (id = (select auth.uid()));

create policy scans_owner_all on public.scans for all to authenticated
  using (user_id = (select auth.uid()))
  with check (user_id = (select auth.uid()));

create policy searches_owner_all on public.searches for all to authenticated
  using (user_id = (select auth.uid()))
  with check (user_id = (select auth.uid()));

create policy results_owner_all on public.results for all to authenticated
  using (user_id = (select auth.uid()))
  with check (user_id = (select auth.uid()));

-- Child rows inherit ownership through the parent result/conversation.
create policy result_sections_owner_all on public.result_sections for all to authenticated
  using (exists (select 1 from public.results r where r.id = result_id and r.user_id = (select auth.uid())))
  with check (exists (select 1 from public.results r where r.id = result_id and r.user_id = (select auth.uid())));

create policy sources_owner_all on public.sources for all to authenticated
  using (exists (select 1 from public.results r where r.id = result_id and r.user_id = (select auth.uid())))
  with check (exists (select 1 from public.results r where r.id = result_id and r.user_id = (select auth.uid())));

create policy discoveries_owner_all on public.discoveries for all to authenticated
  using (user_id = (select auth.uid()))
  with check (user_id = (select auth.uid()));

create policy saved_owner_all on public.saved_items for all to authenticated
  using (user_id = (select auth.uid()))
  with check (user_id = (select auth.uid()));

create policy conversations_owner_all on public.conversations for all to authenticated
  using (user_id = (select auth.uid()))
  with check (user_id = (select auth.uid()));

create policy messages_owner_all on public.messages for all to authenticated
  using (user_id = (select auth.uid()) and exists (
    select 1 from public.conversations c where c.id = conversation_id and c.user_id = (select auth.uid())
  ))
  with check (user_id = (select auth.uid()) and exists (
    select 1 from public.conversations c where c.id = conversation_id and c.user_id = (select auth.uid())
  ));

create policy uploads_owner_all on public.uploads for all to authenticated
  using (user_id = (select auth.uid()))
  with check (user_id = (select auth.uid()));

create policy agent_runs_owner_select on public.agent_runs for select to authenticated
  using (user_id = (select auth.uid()));

create policy tool_calls_owner_select on public.tool_calls for select to authenticated
  using (exists (select 1 from public.agent_runs ar where ar.id = agent_run_id and ar.user_id = (select auth.uid())));

create policy feedback_owner_insert on public.feedback for insert to authenticated
  with check (user_id = (select auth.uid()));

create policy feedback_owner_select on public.feedback for select to authenticated
  using (user_id = (select auth.uid()));

-- Popular searches are intentionally aggregated and contain no user identity.
create policy popular_searches_authenticated_read on public.popular_searches for select to authenticated
  using (true);

-- ---------- UPDATED_AT ----------
create or replace function public.set_updated_at()
returns trigger
language plpgsql
as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

create trigger profiles_set_updated_at before update on public.profiles
for each row execute function public.set_updated_at();

create trigger results_set_updated_at before update on public.results
for each row execute function public.set_updated_at();

create trigger conversations_set_updated_at before update on public.conversations
for each row execute function public.set_updated_at();

-- ---------- PROFILE AUTO-CREATE ----------
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer set search_path = public
as $$
begin
  insert into public.profiles (id, display_name, avatar_url)
  values (
    new.id,
    coalesce(new.raw_user_meta_data ->> 'full_name', new.raw_user_meta_data ->> 'name'),
    new.raw_user_meta_data ->> 'avatar_url'
  )
  on conflict (id) do nothing;
  return new;
end;
$$;

create trigger on_auth_user_created
after insert on auth.users
for each row execute function public.handle_new_user();

-- NOTE: service_role/server-side jobs are intentionally not granted through
-- client policies. Keep secret/service keys only on trusted backend services.
