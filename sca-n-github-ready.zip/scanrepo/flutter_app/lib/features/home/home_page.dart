import 'package:flutter/material.dart';

const _ink = Color(0xFF17231F);
const _green = Color(0xFF286B55);
const _paper = Color(0xFFF7F8F5);
const _muted = Color(0xFF758079);

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int _tab = 0;
  final _search = TextEditingController();
  final List<_Discovery> _recent = [
    _Discovery('Darjeeling', 'Place · West Bengal, India', Icons.landscape_outlined),
    _Discovery('Wireless headphones', 'Product · Identified yesterday', Icons.headphones_outlined),
    _Discovery('Neem leaf', 'Plant · Identified 2 days ago', Icons.eco_outlined),
  ];
  final Set<String> _saved = {'Darjeeling'};

  void _openResult(_Discovery item) => Navigator.of(context).push(MaterialPageRoute(
    builder: (_) => ResultPage(item: item, isSaved: _saved.contains(item.title), onSave: () {
      setState(() => _saved.add(item.title));
    }),
  ));

  @override
  Widget build(BuildContext context) {
    final pages = [
      _home(),
      const ScanPage(),
      SearchPage(onSearch: (q) => _openResult(_Discovery(q, 'AI research · Search result', Icons.auto_awesome_outlined))),
      DiscoveriesPage(items: _recent, onOpen: _openResult),
      ProfilePage(savedCount: _saved.length),
    ];
    return Scaffold(
      backgroundColor: _paper,
      body: SafeArea(child: IndexedStack(index: _tab, children: pages)),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _tab,
        onDestinationSelected: (v) => setState(() => _tab = v),
        backgroundColor: Colors.white,
        indicatorColor: const Color(0xFFE4F0E9),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home_rounded), label: 'Home'),
          NavigationDestination(icon: Icon(Icons.center_focus_strong_outlined), selectedIcon: Icon(Icons.center_focus_strong), label: 'Scan'),
          NavigationDestination(icon: Icon(Icons.search_rounded), label: 'Search'),
          NavigationDestination(icon: Icon(Icons.history_rounded), label: 'Discoveries'),
          NavigationDestination(icon: Icon(Icons.person_outline_rounded), label: 'Profile'),
        ],
      ),
    );
  }

  Widget _home() => ListView(
    padding: const EdgeInsets.fromLTRB(20, 18, 20, 28),
    children: [
      Row(children: [
        Container(width: 42, height: 42, decoration: BoxDecoration(color: const Color(0xFFE3EEE7), borderRadius: BorderRadius.circular(14)), child: const Icon(Icons.center_focus_strong_rounded, color: _green)),
        const SizedBox(width: 11),
        const Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('Sca-N', style: TextStyle(fontSize: 21, fontWeight: FontWeight.w800, color: _ink)), Text('Scan. Understand. Discover.', style: TextStyle(fontSize: 12, color: _muted))])),
        IconButton(onPressed: () => setState(() => _tab = 4), icon: const Icon(Icons.account_circle_outlined, color: _ink)),
      ]),
      const SizedBox(height: 28),
      const Text('Curious about something?', style: TextStyle(fontSize: 25, height: 1.18, fontWeight: FontWeight.w800, color: _ink)),
      const SizedBox(height: 8),
      const Text('Search it, scan it, understand it.', style: TextStyle(color: _muted, fontSize: 14)),
      const SizedBox(height: 20),
      InkWell(onTap: () => setState(() => _tab = 2), borderRadius: BorderRadius.circular(17), child: Container(padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16), decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(17), border: Border.all(color: const Color(0xFFE5EAE6))), child: const Row(children: [Icon(Icons.search, color: _muted), SizedBox(width: 10), Expanded(child: Text('Search anything…', style: TextStyle(color: _muted))), Icon(Icons.mic_none_rounded, color: _green)]))),
      const SizedBox(height: 15),
      InkWell(onTap: () => setState(() => _tab = 1), borderRadius: BorderRadius.circular(22), child: Container(padding: const EdgeInsets.all(21), decoration: BoxDecoration(color: _green, borderRadius: BorderRadius.circular(22)), child: Row(children: [Container(width: 54, height: 54, decoration: BoxDecoration(color: Colors.white.withValues(alpha: .14), borderRadius: BorderRadius.circular(17)), child: const Icon(Icons.center_focus_strong_rounded, color: Colors.white, size: 29)), const SizedBox(width: 15), const Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('Scan anything', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 19)), SizedBox(height: 4), Text('Objects, products, plants, places & more', style: TextStyle(color: Color(0xFFDCECE4), fontSize: 12))])), const Icon(Icons.arrow_forward_rounded, color: Colors.white)])),
      const SizedBox(height: 29),
      _sectionHeader('Recent discoveries', 'View all', () => setState(() => _tab = 3)),
      const SizedBox(height: 12),
      ..._recent.map((item) => _DiscoveryTile(item: item, onTap: () => _openResult(item))),
      const SizedBox(height: 10),
      Container(padding: const EdgeInsets.all(16), decoration: BoxDecoration(color: const Color(0xFFEEF2ED), borderRadius: BorderRadius.circular(18)), child: const Row(children: [Icon(Icons.auto_awesome_outlined, color: _green), SizedBox(width: 12), Expanded(child: Text('One place to identify, learn, compare and save what you discover.', style: TextStyle(color: _ink, fontSize: 13, height: 1.4)))])),
    ],
  );
}

Widget _sectionHeader(String title, String action, VoidCallback onTap) => Row(children: [Expanded(child: Text(title, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w800, color: _ink))), TextButton(onPressed: onTap, child: Text(action, style: const TextStyle(color: _green, fontWeight: FontWeight.w700)))]);

class _Discovery {
  final String title, subtitle;
  final IconData icon;
  const _Discovery(this.title, this.subtitle, this.icon);
}

class _DiscoveryTile extends StatelessWidget {
  final _Discovery item;
  final VoidCallback onTap;
  const _DiscoveryTile({required this.item, required this.onTap});
  @override
  Widget build(BuildContext context) => Padding(padding: const EdgeInsets.only(bottom: 9), child: Material(color: Colors.white, borderRadius: BorderRadius.circular(16), child: InkWell(onTap: onTap, borderRadius: BorderRadius.circular(16), child: Padding(padding: const EdgeInsets.all(13), child: Row(children: [Container(width: 43, height: 43, decoration: BoxDecoration(color: const Color(0xFFF0F3EF), borderRadius: BorderRadius.circular(13)), child: Icon(item.icon, color: _green)), const SizedBox(width: 12), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(item.title, style: const TextStyle(fontWeight: FontWeight.w700, color: _ink)), const SizedBox(height: 3), Text(item.subtitle, style: const TextStyle(color: _muted, fontSize: 12))])), const Icon(Icons.chevron_right_rounded, color: _muted)])))));
}

class ScanPage extends StatelessWidget {
  const ScanPage({super.key});
  @override
  Widget build(BuildContext context) => Padding(padding: const EdgeInsets.all(20), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [const SizedBox(height: 14), const Text('Scan anything', style: TextStyle(fontSize: 26, fontWeight: FontWeight.w800, color: _ink)), const SizedBox(height: 8), const Text('Point your camera at an object, product, plant or place.', style: TextStyle(color: _muted, height: 1.4)), const SizedBox(height: 22), Expanded(child: Container(width: double.infinity, decoration: BoxDecoration(color: const Color(0xFFE7ECE7), borderRadius: BorderRadius.circular(26)), child: Stack(alignment: Alignment.center, children: [const Icon(Icons.camera_alt_outlined, size: 64, color: Color(0xFF8A9A90)), Positioned(top: 28, left: 28, child: _corner()), Positioned(top: 28, right: 28, child: _corner()), Positioned(bottom: 28, left: 28, child: _corner()), Positioned(bottom: 28, right: 28, child: _corner()), const Positioned(bottom: 65, child: Text('Camera preview appears here', style: TextStyle(color: _muted, fontSize: 12)))]))), const SizedBox(height: 18), Row(children: [Expanded(child: FilledButton.icon(onPressed: () => _showNotice(context, 'Camera will be connected in the next integration step.'), icon: const Icon(Icons.camera_alt_outlined), label: const Text('Take photo'), style: FilledButton.styleFrom(backgroundColor: _green, padding: const EdgeInsets.symmetric(vertical: 16)))), const SizedBox(width: 12), Expanded(child: OutlinedButton.icon(onPressed: () => _showNotice(context, 'Gallery picker will be connected in the next integration step.'), icon: const Icon(Icons.photo_library_outlined), label: const Text('Gallery'), style: OutlinedButton.styleFrom(foregroundColor: _green, padding: const EdgeInsets.symmetric(vertical: 16))))]) ]));
  Widget _corner() => Container(width: 32, height: 32, decoration: BoxDecoration(border: Border(top: BorderSide(color: _green, width: 3), left: BorderSide(color: _green, width: 3)), borderRadius: const BorderRadius.only(topLeft: Radius.circular(8))));
}

class SearchPage extends StatefulWidget {
  final ValueChanged<String> onSearch;
  const SearchPage({super.key, required this.onSearch});
  @override
  State<SearchPage> createState() => _SearchPageState();
}
class _SearchPageState extends State<SearchPage> {
  final _controller = TextEditingController();
  final _popular = const ['Why is the sky blue?', 'Places to visit in Odisha', 'How do noise-cancelling headphones work?'];
  @override
  Widget build(BuildContext context) => ListView(padding: const EdgeInsets.fromLTRB(20, 28, 20, 20), children: [const Text('What do you want to know?', style: TextStyle(fontSize: 25, fontWeight: FontWeight.w800, color: _ink)), const SizedBox(height: 8), const Text('Ask a question or search for anything.', style: TextStyle(color: _muted)), const SizedBox(height: 22), TextField(controller: _controller, textInputAction: TextInputAction.search, onSubmitted: (v) { if (v.trim().isNotEmpty) widget.onSearch(v.trim()); }, decoration: InputDecoration(hintText: 'Ask or search anything…', prefixIcon: const Icon(Icons.search), suffixIcon: IconButton(onPressed: () { if (_controller.text.trim().isNotEmpty) widget.onSearch(_controller.text.trim()); }, icon: const Icon(Icons.arrow_forward_rounded, color: _green)), filled: true, fillColor: Colors.white, border: OutlineInputBorder(borderRadius: BorderRadius.circular(17), borderSide: const BorderSide(color: Color(0xFFE5EAE6))), enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(17), borderSide: const BorderSide(color: Color(0xFFE5EAE6))))), const SizedBox(height: 30), const Text('Popular searches', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 17, color: _ink)), const SizedBox(height: 10), ..._popular.map((s) => ListTile(contentPadding: EdgeInsets.zero, leading: const Icon(Icons.trending_up_rounded, color: _green), title: Text(s, style: const TextStyle(fontSize: 14, color: _ink)), trailing: const Icon(Icons.north_west_rounded, size: 17, color: _muted), onTap: () => widget.onSearch(s))), const SizedBox(height: 20), const Text('Explore by location', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 17, color: _ink)), const SizedBox(height: 12), Wrap(spacing: 8, runSpacing: 8, children: ['Nearby', 'A location', 'State', 'Country'].map((s) => Chip(avatar: const Icon(Icons.location_on_outlined, size: 16, color: _green), label: Text(s), backgroundColor: Colors.white, side: const BorderSide(color: Color(0xFFE5EAE6)))).toList())]);
}

class ResultPage extends StatelessWidget {
  final _Discovery item;
  final bool isSaved;
  final VoidCallback onSave;
  const ResultPage({super.key, required this.item, required this.isSaved, required this.onSave});
  @override
  Widget build(BuildContext context) => Scaffold(backgroundColor: _paper, appBar: AppBar(backgroundColor: _paper, title: const Text('Discovery', style: TextStyle(fontWeight: FontWeight.w700)), actions: [IconButton(onPressed: onSave, icon: Icon(isSaved ? Icons.bookmark : Icons.bookmark_border, color: _green))]), body: ListView(padding: const EdgeInsets.all(20), children: [Container(height: 175, decoration: BoxDecoration(color: const Color(0xFFE5ECE6), borderRadius: BorderRadius.circular(22)), child: Icon(item.icon, size: 62, color: _green)), const SizedBox(height: 20), Text(item.title, style: const TextStyle(fontSize: 27, fontWeight: FontWeight.w800, color: _ink)), Text(item.subtitle, style: const TextStyle(color: _muted)), const SizedBox(height: 22), _resultCard('Overview', 'A clear, useful explanation will appear here after Sca-N identifies the subject and verifies relevant information.', Icons.auto_awesome_outlined), _resultCard('Key details', 'Relevant details are selected dynamically for this type of discovery.', Icons.info_outline_rounded), _resultCard('Sources', 'Sources will be shown when external research is used.', Icons.link_rounded), const SizedBox(height: 14), FilledButton.icon(onPressed: () => _showNotice(context, 'Ask More will connect to the AI agent in a later step.'), icon: const Icon(Icons.chat_bubble_outline_rounded), label: const Text('Ask More'), style: FilledButton.styleFrom(backgroundColor: _green, padding: const EdgeInsets.all(16))) ]));
}
Widget _resultCard(String title, String body, IconData icon) => Container(margin: const EdgeInsets.only(bottom: 12), padding: const EdgeInsets.all(17), decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(18), border: Border.all(color: const Color(0xFFE7EBE7))), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Row(children: [Icon(icon, color: _green, size: 20), const SizedBox(width: 9), Text(title, style: const TextStyle(fontWeight: FontWeight.w800, color: _ink))]), const SizedBox(height: 11), Text(body, style: const TextStyle(color: _muted, height: 1.5, fontSize: 13))]));

class DiscoveriesPage extends StatefulWidget {
  final List<_Discovery> items;
  final ValueChanged<_Discovery> onOpen;
  const DiscoveriesPage({super.key, required this.items, required this.onOpen});
  @override
  State<DiscoveriesPage> createState() => _DiscoveriesPageState();
}
class _DiscoveriesPageState extends State<DiscoveriesPage> {
  String _filter = 'All';
  @override
  Widget build(BuildContext context) { final items = _filter == 'All' ? widget.items : widget.items.where((e) => _filter == 'Scans' ? e.subtitle.startsWith('Place') || e.subtitle.startsWith('Product') || e.subtitle.startsWith('Plant') : e.subtitle.startsWith('AI')).toList(); return ListView(padding: const EdgeInsets.fromLTRB(20, 28, 20, 20), children: [const Text('My Discoveries', style: TextStyle(fontSize: 26, fontWeight: FontWeight.w800, color: _ink)), const SizedBox(height: 8), const Text('Your scans and searches, all in one place.', style: TextStyle(color: _muted)), const SizedBox(height: 18), SegmentedButton<String>(segments: const [ButtonSegment(value: 'All', label: Text('All')), ButtonSegment(value: 'Scans', label: Text('Scans')), ButtonSegment(value: 'Searches', label: Text('Searches'))], selected: {_filter}, onSelectionChanged: (s) => setState(() => _filter = s.first)), const SizedBox(height: 20), ...items.map((e) => _DiscoveryTile(item: e, onTap: () => widget.onOpen(e))) ]); }
}

class ProfilePage extends StatelessWidget {
  final int savedCount;
  const ProfilePage({super.key, required this.savedCount});
  @override
  Widget build(BuildContext context) => ListView(padding: const EdgeInsets.fromLTRB(20, 28, 20, 20), children: [const Text('Profile & Settings', style: TextStyle(fontSize: 26, fontWeight: FontWeight.w800, color: _ink)), const SizedBox(height: 18), Container(padding: const EdgeInsets.all(18), decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(20)), child: const Row(children: [CircleAvatar(backgroundColor: Color(0xFFE4F0E9), child: Icon(Icons.person_outline, color: _green)), SizedBox(width: 13), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('Guest user', style: TextStyle(fontWeight: FontWeight.w800, color: _ink)), SizedBox(height: 3), Text('Sign in to sync your discoveries', style: TextStyle(color: _muted, fontSize: 12))])), Icon(Icons.chevron_right, color: _muted)])), const SizedBox(height: 20), _setting(Icons.bookmark_border, 'Saved items', '$savedCount saved'), _setting(Icons.notifications_none, 'Notifications', 'Manage alerts'), _setting(Icons.lock_outline, 'Privacy & data', 'Your data, your control'), _setting(Icons.cloud_outlined, 'Backup & sync', 'Sync across devices'), _setting(Icons.language, 'Language', 'English'), _setting(Icons.help_outline, 'Help & feedback', 'Get support'), _setting(Icons.info_outline, 'About Sca-N', 'Version 0.1.0'), const SizedBox(height: 16), const Text('Privacy-first by design', textAlign: TextAlign.center, style: TextStyle(color: _muted, fontSize: 12))]);
}
Widget _setting(IconData icon, String title, String subtitle) => Container(margin: const EdgeInsets.only(bottom: 8), decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(15)), child: ListTile(leading: Icon(icon, color: _green), title: Text(title, style: const TextStyle(fontWeight: FontWeight.w700, color: _ink, fontSize: 14)), subtitle: Text(subtitle, style: const TextStyle(color: _muted, fontSize: 12)), trailing: const Icon(Icons.chevron_right, color: _muted)));

void _showNotice(BuildContext context, String message) => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));
