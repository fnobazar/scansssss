import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'core/config/env.dart';
import 'core/auth/auth_service.dart';
import 'core/routing/app_router.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  AppEnv.validate();
  await Supabase.initialize(
    url: AppEnv.supabaseUrl,
    publishableKey: AppEnv.supabasePublishableKey,
  );
  final client = Supabase.instance.client;
  runApp(ScaNApp(auth: AuthService(client), client: client));
}

class ScaNApp extends StatelessWidget {
  final AuthService auth;
  final SupabaseClient client;
  const ScaNApp({super.key, required this.auth, required this.client});

  @override
  Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false,
    title: 'Sca-N',
    theme: ThemeData(useMaterial3: true),
    home: SupabaseScope(client: client, child: AppRouter(auth: auth)),
  );
}
