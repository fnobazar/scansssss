import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../auth/auth_service.dart';
import '../../features/home/home_page.dart';

class AppRouter extends StatelessWidget {
  final AuthService auth;
  const AppRouter({super.key, required this.auth});

  @override
  Widget build(BuildContext context) {
    return StreamBuilder(
      stream: auth.authState,
      builder: (context, snapshot) {
        final signedIn = auth.currentUser != null;
        return signedIn ? const HomePage() : const SignInPage();
      },
    );
  }
}

class SignInPage extends StatelessWidget {
  const SignInPage({super.key});
  @override
  Widget build(BuildContext context) {
    final auth = AuthService(SupabaseScope.of(context));
    return Scaffold(
      body: Center(
        child: FilledButton(
          onPressed: auth.signInWithGoogle,
          child: const Text('Continue with Google'),
        ),
      ),
    );
  }
}

class SupabaseScope extends InheritedWidget {
  final SupabaseClient client;
  const SupabaseScope({super.key, required this.client, required super.child});
  static SupabaseClient of(BuildContext context) => context.dependOnInheritedWidgetOfExactType<SupabaseScope>()!.client;
  @override bool updateShouldNotify(covariant SupabaseScope oldWidget) => false;
}
