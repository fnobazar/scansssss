# Sca-N Flutter app

## Local setup

1. Install Flutter.
2. Create a Supabase project.
3. In Supabase Auth, enable Google provider.
4. Configure Google OAuth credentials and add the mobile redirect URI:
   `com.scan.app://login-callback`
5. Run:

```bash
flutter pub get
flutter run --dart-define=SUPABASE_URL=YOUR_URL --dart-define=SUPABASE_PUBLISHABLE_KEY=YOUR_PUBLISHABLE_KEY
```

Never put a Supabase secret/service-role key in Flutter.
