# Sca-N Authentication Setup

## What is implemented
- Supabase Auth client initialization using the publishable key only.
- Google OAuth sign-in entry point.
- Persistent Supabase session handling.
- Auth-state driven routing.
- Backend Bearer-token verification through Supabase JWKS.
- `/v1/me` endpoint that returns only the authenticated internal user id.

## What you must configure once
1. Create a Supabase project.
2. Run `supabase/migrations/0001_initial_schema.sql` in the SQL Editor.
3. In Supabase Authentication, enable Google.
4. Create/configure Google OAuth credentials in Google Cloud / Google Auth Platform.
5. Add the app redirect URI `com.scan.app://login-callback` to the allowed redirect URLs and configure the Android application details as required by Google's current setup.
6. Put only the Supabase project URL + publishable key into Flutter build-time defines.
7. Put the Supabase URL into the backend `.env`.

## Security rules
- Never ship the Supabase service-role/secret key in the mobile app.
- Never send Google profile data to the AI agent unless a feature explicitly requires it.
- Backend must derive the user id from the verified bearer token, never from a client-supplied `user_id`.
- Database access remains protected by RLS.
