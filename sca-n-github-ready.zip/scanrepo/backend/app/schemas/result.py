from typing import Any, Literal
from pydantic import BaseModel, ConfigDict, Field

SectionType = Literal['overview','specifications','price_comparison','pros_cons','history','location','map','reviews','warning','facts','how_it_works','nearby','sources','ask_more']
ActionType = Literal['save','ask_more','compare','buy','open_map','share']

class ResultSection(BaseModel):
    model_config = ConfigDict(extra='forbid')
    type: SectionType
    title: str = Field(min_length=1, max_length=120)
    data: dict[str, Any] = Field(default_factory=dict)

class ResultSource(BaseModel):
    model_config = ConfigDict(extra='forbid')
    title: str = Field(min_length=1, max_length=200)
    url: str | None = None
    publisher: str | None = None
    retrieved_at: str | None = None

class DynamicResult(BaseModel):
    model_config = ConfigDict(extra='forbid')
    result_type: Literal['product','place','object','plant','animal','document','person','palm','general']
    title: str = Field(min_length=1, max_length=200)
    subtitle: str | None = Field(default=None, max_length=300)
    confidence: float = Field(ge=0, le=1)
    image_url: str | None = None
    sections: list[ResultSection] = Field(default_factory=list, max_length=20)
    actions: list[ActionType] = Field(default_factory=list, max_length=10)
    sources: list[ResultSource] = Field(default_factory=list, max_length=30)
    disclaimer: str | None = Field(default=None, max_length=500)
