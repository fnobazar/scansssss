from fastapi import APIRouter, Depends
from app.auth.dependencies import current_user

router = APIRouter()

@router.get('/health')
def health():
    return {'ok': True, 'app': 'Sca-N'}

@router.get('/me')
def me(user=Depends(current_user)):
    return {'user_id': user['id']}
