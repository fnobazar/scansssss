from fastapi import Header, HTTPException
import jwt
from jwt import PyJWKClient
from app.core.config import settings

_jwks_url = settings.supabase_jwks_url or f"{settings.supabase_url}/auth/v1/.well-known/jwks.json"
_jwks = PyJWKClient(_jwks_url)

def current_user(authorization: str | None = Header(default=None)) -> dict:
    if not authorization or not authorization.startswith('Bearer '):
        raise HTTPException(status_code=401, detail='Authentication required')
    token = authorization[7:]
    try:
        key = _jwks.get_signing_key_from_jwt(token).key
        claims = jwt.decode(token, key, algorithms=['ES256','RS256'], options={'verify_aud': False})
        user_id = claims.get('sub')
        if not user_id:
            raise ValueError('Missing subject')
        return {'id': user_id, 'claims': claims}
    except Exception as exc:
        raise HTTPException(status_code=401, detail='Invalid or expired session') from exc
