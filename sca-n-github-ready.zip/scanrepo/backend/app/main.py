from fastapi import FastAPI
from app.api.health import router

app = FastAPI(title='Sca-N API', version='0.1.0')
app.include_router(router, prefix='/v1')
