from app.schemas.result import DynamicResult

async def run_agent(user_id: str, query: str, context: dict | None = None) -> DynamicResult:
    return DynamicResult(
        result_type='general', title='Sca-N',
        subtitle='Dynamic result engine is ready for provider connection.',
        confidence=0.0,
        sections=[{'type':'overview','title':'Ready','data':{'message':'Dynamic result engine is configured.'}}],
        actions=['ask_more'], sources=[]
    )
