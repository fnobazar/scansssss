# Sca-N Dynamic Result Engine

The AI may choose only approved component types. It never generates Flutter layout code, colors, fonts, arbitrary widgets, or navigation.

Flow: Input -> intent -> tools -> verification -> structured result -> Flutter renderer.

Approved section types: overview, specifications, price_comparison, pros_cons, history, location, map, reviews, warning, facts, how_it_works, nearby, sources, ask_more.

The backend validates the structured result before it reaches Flutter.
