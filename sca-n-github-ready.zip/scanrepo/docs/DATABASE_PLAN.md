# Sca-N database plan

The first migration is `supabase/migrations/0001_initial_schema.sql`.

## Security model
- Supabase Auth provides identity.
- `auth.users.id` is the immutable internal user identifier.
- Every private record carries `user_id`, directly or through a protected parent.
- Row Level Security (RLS) is enabled on every exposed table.
- Child records such as result sections, sources, and messages verify ownership through their parent.
- Aggregated popular searches contain no user identifier.
- Service/secret keys remain backend-only.

## Main entities
`profiles`, `scans`, `searches`, `results`, `result_sections`, `sources`, `discoveries`, `saved_items`, `conversations`, `messages`, `uploads`, `agent_runs`, `tool_calls`, `feedback`, `popular_searches`.
